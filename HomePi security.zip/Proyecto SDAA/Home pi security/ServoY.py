
  
from time import sleep
import RPi.GPIO as GPIO
#Configuraciones:
GPIO.setmode(GPIO.BOARD)




def AnguloServoY(angulo):
	assert angulo >=40 and angulo <= 110
	YServo = GPIO.PWM(13, 50)
	YServo.start(5)
	dutyCycle = (angulo + 18*2.5)/18.
	YServo.ChangeDutyCycle(dutyCycle)
	sleep(0.3)
	YServo.stop()
	

if __name__ == '__main__':
	import sys
	GPIO.setup(13, GPIO.OUT)
	AnguloServoY(int(sys.argv[1]))
	GPIO.cleanup()

