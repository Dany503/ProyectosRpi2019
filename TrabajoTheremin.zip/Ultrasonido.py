#!/usr/bin/env python
#-*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
import subprocess
GPIO.setmode(GPIO.BOARD)

#Pines Trigger y Echo de los Ultrasonidos:
GPIO_T1=22
GPIO_E1=26

GPIO_T2=16
GPIO_E2=18


#Pin del Altavoz y valores necesarios 
GPIO_Altavoz=12
frecuencia_altavoz=0.5 #en segundos
duty=50 #Valores entre 0.0 y 100.0
#Frecuencia en Hz de las notas
DO=261 
RE=294
MI=330
FA=349
SOL=392
LA=440
SI=494
DO1=523

d_ini=5 #distancia inicial para el rango de notas (primer escalon)
den=3 #distancia en centimetros entre notas
d_blanca=20 #distancia de referencia a la cual la nota sera una blanca (120ppm)

#Definiciones de pines:
GPIO.setup(GPIO_T1,GPIO.OUT)
GPIO.setup(GPIO_E1,GPIO.IN)
GPIO.setup(GPIO_T2,GPIO.OUT)
GPIO.setup(GPIO_E2,GPIO.IN)

GPIO.setup(GPIO_Altavoz,GPIO.OUT)
Altavoz=GPIO.PWM(GPIO_Altavoz,frecuencia_altavoz)

GPIO.output(GPIO_T1,False)

def MideDistancia(Trigger,Echo):
    GPIO.output(Trigger,True)
    time.sleep(0.00001)
    GPIO.output(Trigger,False)
    
    t_0=time.time()

    while GPIO.input(Echo)==0:
        #Espero a que se active el echo
        pass
        if (time.time()-t_0)>0.05:
            break
    t_inicio=time.time()

    while GPIO.input(Echo)==1:
        #Espero a que se desactive el echo (el pulso ha llegado)
        pass
        if (time.time()-t_0)>0.05:
            break
    t_fin=time.time()

    distancia= (t_fin-t_inicio)*34300/2
    return distancia


if __name__ == '__main__':
    
    while True:
        #Se miden las distancias de los dos ultrasonidos
        distancia1 = MideDistancia(GPIO_T1,GPIO_E1)
        distancia2 = MideDistancia(GPIO_T2,GPIO_E2)

        #Si la distancia1 esta dentro del intervalo, se activa el altavoz
        if distancia1<d_ini+8*den:
            #Se define la frecuencia del sonido en funcion del primer sensor
            if distancia1<d_ini:
                Altavoz.ChangeFrequency(DO)
            elif distancia1<d_ini+den:
                Altavoz.ChangeFrequency(RE)
            elif distancia1<d_ini+2*den:
                Altavoz.ChangeFrequency(MI)
            elif distancia1<d_ini+3*den:
                Altavoz.ChangeFrequency(FA)
            elif distancia1<d_ini+4*den:
                Altavoz.ChangeFrequency(SOL)
            elif distancia1<d_ini+5*den:
                Altavoz.ChangeFrequency(LA)
            elif distancia1<d_ini+6*den:
                Altavoz.ChangeFrequency(SI)
            elif distancia1<d_ini+7*den:
                Altavoz.ChangeFrequency(DO1)
    
            Altavoz.start(duty)

        else:
            #Si la distancia esta fuera de rango, se para el altavoz
            Altavoz.stop()
        
        
        #Si la distancia2 supera el rango, no se espera y se vuelve a leer
        if (distancia2<2*d_blanca):
            #La duracion de la nota sera proporcional a la distancia2 medida (mas distancia, mas duracion)
            time.sleep(distancia2/d_blanca)
            #Se para el altavoz y se duerme 25ms para apreciar los picados entre notas
            Altavoz.stop()
            time.sleep(0.025)
        #print "La distancia medida es de",distancia1,"cm"
        time.sleep(0.025)
